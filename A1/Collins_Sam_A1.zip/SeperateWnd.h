/*******************************************************************
Collins, Sam - A00987689
Comp 3770 Assignment 1
Has the forward declaration for the seperate windows
*******************************************************************/

#pragma once

#include <windows.h>

LRESULT CALLBACK seperateWndProc(HWND, UINT, WPARAM, LPARAM);